package com.cg.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;

public class ApplicantdaoImpl implements Applicantdao {
static int count=4;
	@Override
	public List<Courses> viewCourses() {
		
		return StacticDataBase.getCourses();
	}

	@Override
	public Applicant applyForCourse(Applicant applicant) {
		Applicant applicant1=new Applicant(count++,applicant.getFull_name(), applicant.getDate_of_birth(),applicant.getHighest_qualification(), applicant.getMarks_obtained(),applicant.getGoals(), applicant.getEmail_id(),applicant.getScheduled_program_id(),"under process","Not yet finalised");
		List<Applicant> list=new ArrayList<Applicant>();
		list.add(applicant1);
		StacticDataBase.getApplicant().add(applicant1);
		return applicant1;
	}

	@Override
	public Applicant viewStatus(int appId) {
		
		  for(Applicant app:StacticDataBase.getApplicant()) {
		  if(app.getApplication_id()==appId) { return app; } }
		
		  return null;
	}

}
