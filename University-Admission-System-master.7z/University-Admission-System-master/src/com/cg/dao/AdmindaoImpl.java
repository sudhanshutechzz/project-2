package com.cg.dao;

import java.util.Iterator;
import java.util.List;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.LogIn;
import com.cg.dto.Schedule;
import com.cg.exception.ValidateApplicant;

public class AdmindaoImpl implements Admindao {
	List<Courses> list;
	@Override
	public boolean verifyUser(LogIn login) {
	

		for(LogIn lg:StacticDataBase.getLogin())
		{
			if(login.getUserName().equals(lg.getUserName())&&login.getPassword().equals(lg.getPassword())&&login.getRole().equals(lg.getRole()))
			{
				return true;
				
			}
		
		}
		return false;

	}

	@Override
	public String addCourse(Courses course) {
		 list = StacticDataBase.getCourses();
		boolean flag=false;
		for(Courses cour:list)
		{if(course.getCourseId()==cour.getCourseId())
			flag=true;}
		
		if(flag!=true)
		{
		StacticDataBase.getCourses().add(course);
		return "Course added sucessfully";}
		else
			return "course with courseId already in the list";
	
	}

	@Override
	public String deleteCourse(int course_id) {
		
		list = StacticDataBase.getCourses();
		Iterator<Courses> itr=list.iterator();
		Courses course=new Courses();
		boolean flag=false;
		while(itr.hasNext())
		{
			 course=itr.next();
			if(course.getCourseId()==course_id){
				
				flag=true;
				break;
			}
			
		}
		try{
			list.remove(course);}
			catch(Exception e){
				throw new ValidateApplicant("There is a flow in dao layer");
			}
		
		if(flag){
			return "Course deleted sucessfully";
		}
		else{
			return "Can not find course";
		}

		
	}

	@Override
	public String addSchedule(Schedule schedule) {
		boolean flag=false;
	
		List<Schedule> list1=StacticDataBase.getSchedules();
		for(Schedule sched:list1)
		{if(schedule.getScheduled_program_id()==sched.getScheduled_program_id())
			flag=true;}
		if(flag==false)
		{
		StacticDataBase.getSchedules().add(schedule);
	
		return "Schedule Added Sucessfully";}
		else
			return "Schedule is already exist";
	
}

	@Override
	public String deleteSchedule(int Scheduled_program_id) {
		// TODO Auto-generated method stub
		List<Schedule> list = StacticDataBase.getSchedules();
		Iterator<Schedule> itr=list.iterator();
		Schedule schedule = new Schedule();
		boolean flag=false;
		while(itr.hasNext())
		{
			 schedule=itr.next();
			if(schedule.getScheduled_program_id()==Scheduled_program_id){
				//list.remove(schedule);
				flag=true;break;
			}
			
		}
		try{
			list.remove(schedule);}
			catch(Exception e){
				throw new ValidateApplicant("There is a flow in dao layer");
			}
		if(flag){
			return "Schedule deleted sucessfully";
		}
		else{
			return "Can not found the Schedule program id";
		}
	}

	@Override
	public List<Courses> viewCourses() {
		// TODO Auto-generated method stub
		return  StacticDataBase.getCourses();
	}

	@Override
	public List<Schedule> viewSchedule() {
		
		return StacticDataBase.schedules;
	}

}
