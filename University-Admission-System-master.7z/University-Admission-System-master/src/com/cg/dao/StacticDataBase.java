package com.cg.dao;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.LogIn;
import com.cg.dto.Schedule;

public class StacticDataBase {
	private static List<Courses> courses=new ArrayList<Courses>();
	static List<Applicant> applicant=new ArrayList<Applicant>();
	static List<LogIn> login=new ArrayList<LogIn>(); 
	static List<Schedule> schedules = new ArrayList<Schedule>();
	 public static List<Schedule> getSchedules() {
		return schedules;
	}
	public static void setSchedules(List<Schedule> schedules) {
		StacticDataBase.schedules = schedules;
	}
	static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
     
	public static List<Courses> getCourses() {
		return courses;
	}
	public static void setCourses(List<Courses> courses) {
		StacticDataBase.courses = courses;
	}
	public static List<Applicant> getApplicant() {
		return applicant;
	}
	public static void setApplicant(List<Applicant> applicant) {
		StacticDataBase.applicant = applicant;
	}
	public static List<LogIn> getLogin() {
		return login;
	}
	public static void setLogin(List<LogIn> login) {
		StacticDataBase.login = login;
	}
	static{
		courses.add(new Courses(1,"MBA","It is for professionals","Graduation",2,"MBA"));
		courses.add(new Courses(2,"Btech","It is for professionals","12th",4,"Btech"));
		courses.add(new Courses(3,"BBA","It is for professionals","12th",3,"BBA"));
	}
	static{
		login.add(new LogIn("surya","surya","Applicant"));
		login.add(new LogIn("prerak","prerak","MAC"));
		login.add(new LogIn("surya","surya","Admin"));
	}
	static
	{
		applicant.add(new Applicant(1,"Sudhanshu","09/12/1997","Btech",90f,"good prograammar","Sudhanshurajpal9741@gmail.com",1,"under process","not yet finalised"));
		applicant.add(new Applicant(2,"Sudhanshu","09/12/1997","HSC",90f,"good prograammar","Sudhanshurajpal9741@gmail.com",2,"under process","not yet finalised"));
		applicant.add(new Applicant(3,"Sudhanshu","09/12/1997","HSC",90f,"good prograammar","Sudhanshurajpal9741@gmail.com",2,"under process","not yet finalised"));
	}
	static {
		schedules.add(new Schedule(1,"MBA","Pune","05/06/2020","12/20/2020" ,2));
		schedules.add(new Schedule(2,"Btech","Mumbai","05/06/2020","12/20/2020",2));
	}
}
