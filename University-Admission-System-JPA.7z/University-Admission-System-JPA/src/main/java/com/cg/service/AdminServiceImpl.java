package com.cg.service;
import java.util.List;
import com.cg.dao.Admindao;
import com.cg.dao.AdmindaoImpl;
import com.cg.dao.MACdao;
import com.cg.dao.MACdaoImpl;
import com.cg.dto.Courses;
import com.cg.dto.LogIn;
import com.cg.dto.Schedule;

public class AdminServiceImpl implements AdminService {

	Admindao admindao = new AdmindaoImpl();
	MACdao mdao = new MACdaoImpl();
	@Override
	public boolean verifyUser(String username, String Password, String role) {
		return admindao.verifyUser(new LogIn(username,Password,role));
	}

	@Override
	public String addCourse(int CourseId,String ProgramName, String description, String applicant_eligibility, int duration,
			String degree_certificate_offered) {
		// TODO Auto-generated method stub
		
		return admindao.addCourse(new Courses(CourseId,ProgramName,description,applicant_eligibility,duration,degree_certificate_offered));
	}

	@Override
	public String deleteCourse(int course_id) {
		// TODO Auto-generated method stub
		return admindao.deleteCourse(course_id);
	}

	@Override
	public String addSchedule(int Scheduled_program_id, String ProgramName, String Location, String start_date,
			String end_date,int sessions_per_week) {
		// TODO Auto-generated method stub
		return admindao.addSchedule(new Schedule(Scheduled_program_id,ProgramName,Location,start_date,end_date,sessions_per_week));
	}

	@Override
	public String deleteSchedule(int Scheduled_program_id) {
		// TODO Auto-generated method stub
		return admindao.deleteSchedule(Scheduled_program_id);
	}

	@Override
	public List<Courses> viewCourses() {
		// TODO Auto-generated method stub
		return admindao.viewCourses();
	}
	@Override
	public List<Schedule> viewSchedule() {
		// TODO Auto-generated method stub
		return admindao.viewSchedule();
	}

}
