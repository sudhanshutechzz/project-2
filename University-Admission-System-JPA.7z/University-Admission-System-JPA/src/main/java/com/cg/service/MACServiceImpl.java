package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.dao.MACdao;
import com.cg.dao.MACdaoImpl;
import com.cg.dto.Applicant;
import com.cg.dto.LogIn;

public class MACServiceImpl implements MACService {
	MACdao mdao=new MACdaoImpl();
	public boolean verifyUser(String username,String Password,String role){
		return mdao.verifyUser(new LogIn(username,Password,role));
	}

	@Override
	public List<Applicant> getApplicantsByCourseId(int CourseId) {
		// TODO Auto-generated method stub
		return mdao.getApplicantsByCourseId(CourseId);
	}

	@Override
	public String sheduleInterview(int applicant, String date) {
		// TODO Auto-generated method stub
		return mdao.sheduleInterview(applicant,date);
	}

	@Override
	public String updateStatus(int applicationId, int status) {
		// TODO Auto-generated method stub
		return mdao.updateStatus(applicationId,status);
	}
}
