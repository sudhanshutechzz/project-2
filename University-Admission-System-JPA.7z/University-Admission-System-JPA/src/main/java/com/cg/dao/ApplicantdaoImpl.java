package com.cg.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;

public class ApplicantdaoImpl implements Applicantdao {
static int count=4;
EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
EntityManager em=emf.createEntityManager();
	@Override
	public List<Courses> viewCourses() {
		
		return em.createQuery("SELECT a FROM Courses a",Courses.class).getResultList();
	}

	@Override
	public Applicant applyForCourse(Applicant applicant) {
		Applicant applicant1=new Applicant(0,applicant.getFull_name(), applicant.getDate_of_birth(),applicant.getHighest_qualification(), applicant.getMarks_obtained(),applicant.getGoals(), applicant.getEmail_id(),applicant.getScheduled_program_id(),"under process","Not yet finalised");
		/*
		 * List<Applicant> list=new ArrayList<Applicant>(); list.add(applicant1);
		 * StacticDataBase.setApplicant(list);
		 */
		em.getTransaction().begin();
		em.persist(applicant1);
		em.getTransaction().commit();
		return applicant1;
	}

	@Override
	public Applicant viewStatus(int appId) {
			Applicant app=em.find(Applicant.class, appId);
		 
		  if(app==null) { return null; }
		  else
			  return app;
		
		  
	}

}
