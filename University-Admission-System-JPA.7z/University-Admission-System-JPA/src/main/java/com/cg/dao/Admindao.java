package com.cg.dao;

import java.util.List;

import com.cg.dto.Courses;
import com.cg.dto.LogIn;
import com.cg.dto.Schedule;

public interface Admindao {
	public boolean verifyUser(LogIn login);
	public List<Courses> viewCourses();
	public String addCourse(Courses course);
	public String deleteCourse(int course_id);
	public String addSchedule(Schedule schedule);
	public String deleteSchedule(int Scheduled_program_id);
	public List<Schedule> viewSchedule();
}
